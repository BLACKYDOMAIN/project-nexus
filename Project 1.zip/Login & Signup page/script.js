function validateLoginForm() {
    let username = document.forms["loginForm"]["username"].value;
    let password = document.forms["loginForm"]["password"].value;
    if (username == "" || password == "") {
      alert("All fields must be filled out");
      return false;
    }
  }
  
  function validateSignupForm() {
    let username = document.forms["signupForm"]["username"].value;
    let password = document.forms["signupForm"]["password"].value;
  
    let passwordPolicy = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\W_]).{8,}$/;
    
    if (username == "" || password == "") {
      alert("All fields must be filled out");
      return false;
    }
  
    if (!password.match(passwordPolicy)) {
      alert("Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character.");
      return false;
    }
  }
  
  function showSignupForm() {
    document.getElementById("loginForm").style.display = "none";
    document.getElementById("signupForm").style.display = "block";
  }
  
  function showLoginForm() {
    document.getElementById("signupForm").style.display = "none";
    document.getElementById("loginForm").style.display = "block";
  }
  